import { Server as SocketIOServer } from 'socket.io';
import { ProxmoxManager, ProxmoxContainer } from './ProxmoxManager';
import { DatabaseManager, Service } from './DatabaseManager';

export class ServiceDiscovery {
  private interval: NodeJS.Timeout | null = null;
  private previousServices: Map<string, Service> = new Map();

  constructor(
    private db: DatabaseManager,
    private proxmox: ProxmoxManager,
    private io: SocketIOServer,
  ) {}

  startDiscovery(): void {
    console.log('Starting service discovery');
    
    // Run discovery immediately
    this.discoverServices();
    
    // Run every 30 seconds
    this.interval = setInterval(() => {
      this.discoverServices();
    }, 30000);
  }

  stopDiscovery(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  private async discoverServices(): Promise<void> {
    try {
      const containers = await this.proxmox.getContainers();
      const currentServices = new Map<string, Service>();

      for (const container of containers) {
        try {
          const services = await this.getServicesFromContainer(container);
          
          for (const service of services) {
            currentServices.set(service.id, service);
            
            // Check if this is a new or updated service
            const previousService = this.previousServices.get(service.id);
            
            if (!previousService) {
              // New service
              await this.db.saveService({
                name: service.name,
                url: service.url,
                icon: service.icon,
                description: service.description,
                containerName: service.containerName,
                containerType: service.containerType,
                containerId: service.containerId,
                port: service.port,
                ip: service.ip,
              });

              this.io.emit('service:added', service);
              console.log('New service discovered:', service.name);
            } else if (JSON.stringify(previousService) !== JSON.stringify(service)) {
              // Service updated
              await this.db.saveService({
                name: service.name,
                url: service.url,
                icon: service.icon,
                description: service.description,
                containerName: service.containerName,
                containerType: service.containerType,
                containerId: service.containerId,
                port: service.port,
                ip: service.ip,
              });

              this.io.emit('service:updated', service);
              console.log('Service updated:', service.name);
            }
          }
        } catch (error) {
          console.error(`Error discovering services in container ${container.name}:`, error);
        }
      }

      // Check for removed services
      for (const [serviceId, service] of this.previousServices) {
        if (!currentServices.has(serviceId)) {
          this.io.emit('service:removed', { id: serviceId, name: service.name });
          console.log('Service removed:', service.name);
        }
      }

      this.previousServices = currentServices;
    } catch (error) {
      console.error('Error during service discovery:', error);
    }
  }

  private async getServicesFromContainer(
    container: ProxmoxContainer,
  ): Promise<Service[]> {
    const services: Service[] = [];

    // Mock services for demo purposes
    if (container.name.toLowerCase().includes('immich')) {
      services.push(this.createMockService(container, 'immich', 2283, '192.168.1.100'));
    } else if (container.name.toLowerCase().includes('jellyfin')) {
      services.push(this.createMockService(container, 'jellyfin', 8096, '192.168.1.101'));
    } else if (container.name.toLowerCase().includes('radarr')) {
      services.push(this.createMockService(container, 'radarr', 7878, '192.168.1.102'));
    } else if (container.name.toLowerCase().includes('sonarr')) {
      services.push(this.createMockService(container, 'sonarr', 8989, '192.168.1.103'));
    } else if (container.name.toLowerCase().includes('lidarr')) {
      services.push(this.createMockService(container, 'lidarr', 8686, '192.168.1.104'));
    } else if (container.name.toLowerCase().includes('qbittorrent')) {
      services.push(this.createMockService(container, 'qbittorrent', 6881, '192.168.1.105'));
    } else if (container.name.toLowerCase().includes('nextcloud')) {
      services.push(this.createMockService(container, 'nextcloud', 80, '192.168.1.106'));
    } else if (container.name.toLowerCase().includes('bitwarden')) {
      services.push(this.createMockService(container, 'bitwarden', 80, '192.168.1.107'));
    } else if (container.name.toLowerCase().includes('grafana')) {
      services.push(this.createMockService(container, 'grafana', 3000, '192.168.1.108'));
    } else if (container.name.toLowerCase().includes('prometheus')) {
      services.push(this.createMockService(container, 'prometheus', 9090, '192.168.1.109'));
    } else if (container.name.toLowerCase().includes('portainer')) {
      services.push(this.createMockService(container, 'portainer', 9000, '192.168.1.110'));
    } else if (container.name.toLowerCase().includes('ubuntu') || container.name.toLowerCase().includes('debian')) {
      // Generate multiple services for generic servers
      const baseIP = `192.168.1.${100 + container.vmid}`;
      services.push(this.createMockService(container, 'ubuntu-web', 80, baseIP));
      services.push(this.createMockService(container, 'ubuntu-app', 3000, baseIP));
      services.push(this.createMockService(container, 'ubuntu-api', 5000, baseIP));
    }

    return services;
  }

  private createMockService(
    container: ProxmoxContainer,
    serviceName: string,
    port: number,
    ip: string,
  ): Service {
    const descriptions: Record<string, string> = {
      immich: 'Photo & video management',
      jellyfin: 'Media server streaming',
      radarr: 'Movie collection manager',
      sonarr: 'TV series manager',
      lidarr: 'Music library manager',
      qbittorrent: 'Torrent downloader',
      nextcloud: 'Cloud storage & sync',
      bitwarden: 'Password manager',
      grafana: 'Metrics visualization',
      prometheus: 'Monitoring & alerting',
      portainer: 'Container management',
      'ubuntu-web': 'Web server',
      'ubuntu-app': 'Application server',
      'ubuntu-api': 'REST API service',
    };

    return {
      id: `${container.vmid}-${serviceName}-${port}`,
      name: serviceName.charAt(0).toUpperCase() + serviceName.slice(1),
      url: `http://${ip}:${port}`,
      description: descriptions[serviceName] || 'Service',
      containerName: container.name,
      containerType: container.type === 'lxc' ? 'lxc' : 'qemu',
      containerId: container.vmid,
      port,
      ip,
      lastUpdated: new Date(),
    };
  }

  private async getContainerIP(): Promise<string | null> {
    try {
      return '192.168.1.100';
    } catch (error) {
      console.error('Error getting container IP:', error);
      return null;
    }
  }

  private async detectOpenPorts(): Promise<number[]> {
    const commonPorts = [80, 443, 3000, 5000, 8000, 8080, 8443, 9000, 3001];
    return commonPorts;
  }
}
