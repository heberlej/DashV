import axios, { AxiosInstance } from 'axios';
import https from 'https';
import http from 'http';

export interface ProxmoxConfig {
  host: string;
  port?: number;
  user: string;
  token: string;
}

export interface ProxmoxContainer {
  vmid: number;
  name: string;
  status: string;
  type: string;
}

export class ProxmoxManager {
  private client: AxiosInstance | null = null;
  private mockMode = process.env.MOCK_PROXMOX === 'true';

  async connect(config: ProxmoxConfig): Promise<boolean> {
    try {
      if (this.mockMode) {
        console.log('[MOCK MODE] Simulating Proxmox connection...');
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log('[MOCK MODE] Connection successful');
        return true;
      }
      
      // Use custom port or default to 8006
      const port = config.port || 8006;
      
      // Create axios instance with Proxmox API settings
      const httpsAgent = new https.Agent({
        rejectUnauthorized: false,
        keepAlive: false,
        timeout: 2000,
      });
      
      this.client = axios.create({
        baseURL: `https://${config.host}:${port}/api2/json`,
        headers: {
          'Authorization': `PVEAPIToken=${config.token}`,
        },
        httpAgent: undefined,
        httpsAgent: httpsAgent,
        timeout: 2000,
      });

      // Test connection using raw fetch to bypass axios issues
      console.log(`[Proxmox] Testing connection to ${config.host}:${port}...`);
      
      const url = `https://${config.host}:${port}/api2/json/version`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);
      
      try {
        const response = await fetch(url, {
          headers: {
            'Authorization': `PVEAPIToken=${config.token}`,
          },
          signal: controller.signal as any,
        });
        clearTimeout(timeoutId);
        
        if (response.ok) {
          console.log('[Proxmox] ✓ Connection successful');
          return true;
        } else {
          console.error(`[Proxmox] ✗ Server returned: ${response.status}`);
          return false;
        }
      } catch (fetchError: any) {
        clearTimeout(timeoutId);
        console.error(`[Proxmox] ✗ Fetch failed: ${fetchError.message}`);
        return false;
      }
      
      return false;
    } catch (error) {
      console.error('[Proxmox] ✗ Connection error:', error);
      this.client = null;
      return false;
    }
  }

  async getContainers(): Promise<ProxmoxContainer[]> {
    if (this.mockMode) {
      console.log('[MOCK MODE] Returning mock containers');
      return [
        { vmid: 100, name: 'immich', status: 'running', type: 'lxc' },
        { vmid: 101, name: 'jellyfin', status: 'running', type: 'lxc' },
        { vmid: 102, name: 'radarr', status: 'running', type: 'lxc' },
        { vmid: 103, name: 'sonarr', status: 'running', type: 'lxc' },
        { vmid: 104, name: 'lidarr', status: 'running', type: 'lxc' },
        { vmid: 105, name: 'qbittorrent', status: 'running', type: 'lxc' },
        { vmid: 106, name: 'nextcloud', status: 'running', type: 'lxc' },
        { vmid: 107, name: 'bitwarden', status: 'running', type: 'lxc' },
        { vmid: 108, name: 'grafana', status: 'running', type: 'lxc' },
        { vmid: 109, name: 'prometheus', status: 'running', type: 'lxc' },
        { vmid: 110, name: 'portainer', status: 'running', type: 'lxc' },
      ];
    }
    
    if (!this.client) {
      throw new Error('Not connected to Proxmox');
    }

    try {
      // Get all nodes
      const nodesResponse = await this.client.get('/nodes');
      const nodes = nodesResponse.data.data;

      const containers: ProxmoxContainer[] = [];

      // For each node, get containers
      for (const node of nodes) {
        try {
          const lxcResponse = await this.client.get(`/nodes/${node.node}/lxc`);
          const lxcContainers = lxcResponse.data.data || [];
          containers.push(...lxcContainers);

          const qemuResponse = await this.client.get(`/nodes/${node.node}/qemu`);
          const qemuVMs = qemuResponse.data.data || [];
          containers.push(...qemuVMs);
        } catch (error) {
          console.error(`Error fetching containers from node ${node.node}:`, error);
        }
      }

      return containers;
    } catch (error) {
      console.error('Error getting containers:', error);
      throw error;
    }
  }

  async executeInContainer(
    node: string,
    vmid: number,
  ): Promise<string> {
    if (!this.client) {
      throw new Error('Not connected to Proxmox');
    }

    try {
      // Note: This is a simplified version. Actual implementation would need
      // to handle LXC exec properly via Proxmox API
      const response = await this.client.post(
        `/nodes/${node}/lxc/${vmid}/status/current`,
      );
      return response.data.toString();
    } catch (error) {
      console.error('Error executing command:', error);
      throw error;
    }
  }
}
