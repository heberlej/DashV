import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import { ProxmoxManager } from './services/ProxmoxManager';
import { DatabaseManager } from './services/DatabaseManager';
import { ServiceDiscovery } from './services/ServiceDiscovery';

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST'],
  },
});

// Middleware
app.use(cors());
app.use(express.json());

// Database
const db = new DatabaseManager();

// Initialize Proxmox and Service Discovery
const proxmox = new ProxmoxManager();
const serviceDiscovery = new ServiceDiscovery(db, proxmox, io);

// Routes
app.get('/health', (_req, res) => {
  res.json({ status: 'ok' });
});

app.get('/api/services', async (_req, res) => {
  try {
    const services = await db.getAllServices();
    res.json(services);
  } catch (error) {
    console.error('Error fetching services:', error);
    res.status(500).json({ error: 'Failed to fetch services' });
  }
});

app.post('/api/proxmox/connect', async (req, res): Promise<void> => {
  try {
    const { host, port, user, token } = req.body;
    
    console.log(`[DEBUG] Proxmox connect request: host=${host}, port=${port}, user=${user}, token=${token?.substring(0, 10)}...`);
    
    if (!host || !user || !token) {
      console.log('[DEBUG] Missing required fields');
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    console.log('[DEBUG] Attempting to connect to Proxmox...');
    // Validate connection
    const connected = await proxmox.connect({
      host,
      port: port || 8006,
      user,
      token,
    });

    console.log(`[DEBUG] Proxmox connection result: ${connected}`);
    if (!connected) {
      res.status(401).json({ error: 'Failed to connect to Proxmox' });
      return;
    }

    // Save connection
    await db.saveProxmoxConnection({ host, user, token });

    // Start service discovery
    serviceDiscovery.startDiscovery();

    console.log('[DEBUG] Connection successful, sending response');
    res.json({ success: true });
  } catch (error) {
    console.error('Error connecting to Proxmox:', error);
    res.status(500).json({ error: 'Failed to connect to Proxmox' });
  }
});

// WebSocket events
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3001;

server.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);
  
  try {
    await db.initialize();
    console.log('Database initialized');
    
    // Auto-start service discovery in MOCK mode
    if (process.env.MOCK_PROXMOX === 'true') {
      console.log('[MOCK MODE] Auto-starting service discovery...');
      await proxmox.connect({
        host: 'mock',
        port: 8006,
        user: 'mock',
        token: 'mock',
      });
      serviceDiscovery.startDiscovery();
    }
  } catch (error) {
    console.error('Failed to initialize:', error);
  }
});
