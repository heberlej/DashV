import { FC, useState } from 'react';

const ProxmoxConnector: FC = () => {
  const [host, setHost] = useState('');
  const [port, setPort] = useState('8006');
  const [user, setUser] = useState('');
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL || 'http://localhost:3001'}/api/proxmox/connect`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ host, port: parseInt(port), user, token }),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to connect');
      }

      alert('Connected to Proxmox successfully!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Connection failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleConnect}
      className="w-full max-w-md mx-auto"
    >
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 p-0.5">
        <div className="bg-gray-950 rounded-2xl p-8 space-y-6">
          <div>
            <h2 className="text-2xl font-bold gradient-text mb-2">Connect Proxmox</h2>
            <p className="text-gray-400 text-sm">Enter your Proxmox instance details</p>
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-200 p-4 rounded-lg text-sm backdrop-blur">
              <p className="font-medium mb-1">Connection Error</p>
              <p>{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-200 mb-2">
                Proxmox Host
              </label>
              <input
                type="text"
                placeholder="proxmox.example.com"
                value={host}
                onChange={(e) => setHost(e.target.value)}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-200 mb-2">
                Port
              </label>
              <input
                type="number"
                placeholder="8006"
                value={port}
                onChange={(e) => setPort(e.target.value)}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 transition-all"
                min="1"
                max="65535"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-200 mb-2">
                User (e.g. root@pam)
              </label>
              <input
                type="text"
                placeholder="root@pam"
                value={user}
                onChange={(e) => setUser(e.target.value)}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-200 mb-2">
                API Token <span className="text-gray-400 text-xs font-normal">(format: tokenid:secret)</span>
              </label>
              <input
                type="password"
                placeholder="dashpve:42880ee7-d366-4f93-b11f-a70cefa97963"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-95"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  Connecting...
                </span>
              ) : (
                'Connect to Proxmox'
              )}
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default ProxmoxConnector;
