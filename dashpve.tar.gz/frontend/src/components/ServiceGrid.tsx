import { FC, useState } from 'react';

interface Service {
  id: string;
  name: string;
  url: string;
  icon?: string;
  description?: string;
  containerName: string;
  port: number;
  ip: string;
}

interface ServiceGridProps {
  services: Service[];
}

const ServiceGrid: FC<ServiceGridProps> = ({ services }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Categorize services based on name/port
  const categorizeService = (service: Service): string => {
    const name = service.name.toLowerCase();
    const port = service.port;

    if (name.includes('immich') || name.includes('photo') || name.includes('gallery')) return 'media';
    if (name.includes('jellyfin') || name.includes('plex') || name.includes('kaleidescape')) return 'media';
    if (name.includes('radarr') || name.includes('sonarr') || name.includes('lidarr')) return 'media';
    if (name.includes('qbittorrent') || name.includes('transmission') || name.includes('sab')) return 'media';
    if (name.includes('nextcloud') || name.includes('synology')) return 'productivity';
    if (name.includes('bitwarden') || name.includes('vaultwarden')) return 'productivity';
    if (name.includes('paperless') || name.includes('calibre')) return 'productivity';
    if (name.includes('gitea') || name.includes('gitlab') || name.includes('jenkins')) return 'development';
    if (name.includes('portainer') || name.includes('docker')) return 'development';
    if (name.includes('prometheus') || name.includes('grafana') || name.includes('influx')) return 'monitoring';
    if (name.includes('postgresql') || name.includes('mysql') || name.includes('mongo')) return 'storage';
    if (name.includes('pihole') || name.includes('adguard')) return 'system';
    if (name.includes('openvpn') || name.includes('wireguard')) return 'system';
    if (name.includes('homeassistant') || name.includes('home-assistant')) return 'home';

    // Category by port
    if ([80, 443, 3000, 3001, 5000, 5173, 8000, 8080].includes(port)) return 'productivity';
    if ([3306, 5432, 6379, 27017].includes(port)) return 'storage';
    if ([9090, 9091].includes(port)) return 'monitoring';

    return 'other';
  };

  const getServiceIcon = (service: Service): string => {
    const name = service.name.toLowerCase();

    if (name.includes('immich')) return '🖼️';
    if (name.includes('jellyfin')) return '🎬';
    if (name.includes('plex')) return '🎥';
    if (name.includes('radarr')) return '🎬';
    if (name.includes('sonarr')) return '📺';
    if (name.includes('lidarr')) return '🎵';
    if (name.includes('qbittorrent') || name.includes('transmission')) return '🌐';
    if (name.includes('nextcloud')) return '☁️';
    if (name.includes('bitwarden') || name.includes('vaultwarden')) return '🔐';
    if (name.includes('paperless')) return '📄';
    if (name.includes('calibre')) return '📚';
    if (name.includes('gitea') || name.includes('gitlab')) return '🐙';
    if (name.includes('jenkins')) return '🔨';
    if (name.includes('portainer') || name.includes('docker')) return '🐳';
    if (name.includes('prometheus')) return '📊';
    if (name.includes('grafana')) return '📈';
    if (name.includes('postgresql')) return '🐘';
    if (name.includes('mysql')) return '🐬';
    if (name.includes('mongodb')) return '🍃';
    if (name.includes('redis')) return '🔴';
    if (name.includes('pihole')) return '🕳️';
    if (name.includes('openvpn') || name.includes('wireguard')) return '🔒';
    if (name.includes('homeassistant') || name.includes('home-assistant')) return '🏠';
    if (name.includes('nginx') || name.includes('apache')) return '⚙️';
    if (name.includes('ubuntu') || name.includes('debian')) return '🐧';
    if (name.includes('windows')) return '🪟';

    return '📦';
  };

  const getServiceColor = (service: Service): string => {
    const category = categorizeService(service);

    const colors: Record<string, string> = {
      media: 'from-purple-500 to-pink-500',
      productivity: 'from-blue-500 to-cyan-500',
      development: 'from-orange-500 to-red-500',
      monitoring: 'from-yellow-500 to-orange-500',
      storage: 'from-green-500 to-emerald-500',
      system: 'from-gray-600 to-gray-700',
      home: 'from-indigo-500 to-blue-500',
      other: 'from-gray-500 to-gray-600',
    };

    return colors[category] || colors.other;
  };

  // Filter and search
  const filteredServices = services.filter((service) => {
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || categorizeService(service) === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  // Get unique categories
  const categories = Array.from(new Set(services.map(categorizeService)));

  return (
    <div className="space-y-8">
      {/* Search Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <input
          type="text"
          placeholder="🔍 Search services..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1 px-6 py-3 rounded-xl bg-gray-800 text-white placeholder-gray-400 border border-gray-700 focus:border-blue-500 focus:outline-none transition-colors"
        />
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            selectedCategory === null
              ? 'bg-blue-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
        >
          All
        </button>
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg font-medium transition-all capitalize ${
              selectedCategory === category
                ? 'bg-blue-600 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Service Grid */}
      {filteredServices.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-gray-400 text-lg">
            {searchTerm ? 'No services found matching your search.' : 'No services available.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredServices.map((service) => (
            <a
              key={service.id}
              href={service.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`group relative overflow-hidden rounded-2xl bg-gradient-to-br ${getServiceColor(service)} p-[2px] transition-all duration-300 hover:shadow-2xl hover:scale-105 hover:shadow-blue-500/50 cursor-pointer`}
            >
              <div className="relative h-full bg-gradient-to-br from-gray-900 to-gray-950 rounded-[15px] p-6 flex flex-col justify-between min-h-[250px]">
                {/* Top Section: Icon */}
                <div className="flex items-start justify-between mb-4">
                  <div className="text-6xl group-hover:scale-125 group-hover:rotate-6 transition-all duration-300 drop-shadow-lg">
                    {getServiceIcon(service)}
                  </div>
                  <div className="text-3xl opacity-20 group-hover:opacity-40 transition-opacity group-hover:translate-x-1">
                    ↗
                  </div>
                </div>

                {/* Middle Section: Title and Description */}
                <div className="flex-grow">
                  <h3 className="text-2xl font-bold text-white group-hover:text-blue-300 transition-colors mb-2 leading-tight">
                    {service.name}
                  </h3>
                  {service.description && (
                    <p className="text-sm text-gray-300 group-hover:text-gray-100 transition-colors line-clamp-2">
                      {service.description}
                    </p>
                  )}
                </div>

                {/* Bottom Section: Details */}
                <div className="pt-4 border-t border-gray-700/50 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-400">Container</span>
                    <span className="text-gray-200 font-mono text-[11px] bg-gray-800/50 px-2 py-1 rounded">
                      {service.containerName}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-400">Address</span>
                    <span className="text-gray-200 font-mono text-[11px] bg-gray-800/50 px-2 py-1 rounded">
                      {service.ip}:{service.port}
                    </span>
                  </div>
                </div>

                {/* Animated Border Gradient */}
                <div className="absolute inset-0 rounded-[15px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 pointer-events-none" />
              </div>
            </a>
          ))}
        </div>
      )}

      {/* Service Count */}
      <div className="text-center pt-8 border-t border-gray-800">
        <p className="text-gray-400 text-sm">
          Showing {filteredServices.length} of {services.length} services
        </p>
      </div>
    </div>
  );
};

export default ServiceGrid;
