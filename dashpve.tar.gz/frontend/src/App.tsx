import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import ServiceGrid from './components/ServiceGrid';
import ProxmoxConnector from './components/ProxmoxConnector';

interface Service {
  id: string;
  name: string;
  url: string;
  icon?: string;
  description?: string;
  containerName: string;
  port: number;
  ip: string;
}

function App() {
  const [services, setServices] = useState<Service[]>([]);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Connect to WebSocket
    const newSocket = io(import.meta.env.VITE_API_URL || 'http://localhost:3001');

    newSocket.on('connect', () => {
      setConnected(true);
      console.log('Connected to server');
    });

    newSocket.on('disconnect', () => {
      setConnected(false);
      console.log('Disconnected from server');
    });

    // Listen for service updates
    newSocket.on('service:added', (service: Service) => {
      setServices((prev) => [...prev, service]);
      console.log('Service added:', service.name);
    });

    newSocket.on('service:updated', (service: Service) => {
      setServices((prev) =>
        prev.map((s) => (s.id === service.id ? service : s))
      );
      console.log('Service updated:', service.name);
    });

    newSocket.on('service:removed', (data: { id: string; name: string }) => {
      setServices((prev) => prev.filter((s) => s.id !== data.id));
      console.log('Service removed:', data.name);
    });

    // Fetch initial services
    fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3001'}/api/services`)
      .then((res) => res.json())
      .then((data) => setServices(data))
      .catch((error) => console.error('Failed to fetch services:', error));

    return () => {
      newSocket.disconnect();
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-black text-white overflow-x-hidden">
      {/* Animated Background with multiple blur layers */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute top-0 -left-40 w-80 h-80 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 -right-40 w-80 h-80 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-40 left-40 w-80 h-80 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-600 rounded-full mix-blend-multiply filter blur-3xl opacity-15 animate-blob animation-delay-3000"></div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-gray-800/50 backdrop-blur-xl bg-gray-900/30 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex items-end justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-4xl">🚀</span>
                  <h1 className="text-5xl font-black bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                    DashPVE
                  </h1>
                </div>
                <p className="text-gray-400 text-lg ml-14">Proxmox Service Discovery Dashboard</p>
              </div>
              <div className="flex items-center gap-3 px-5 py-3 bg-gray-800/30 rounded-xl backdrop-blur border border-gray-700/50 hover:border-gray-600/50 transition-colors">
                <div
                  className={`w-3 h-3 rounded-full flex-shrink-0 ${
                    connected ? 'bg-green-500 animate-pulse shadow-lg shadow-green-500/50' : 'bg-red-500 shadow-lg shadow-red-500/50'
                  }`}
                />
                <span className="text-sm font-semibold">
                  {connected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {services.length === 0 ? (
            <div className="flex items-center justify-center min-h-[500px]">
              <div className="text-center space-y-8">
                <div className="text-8xl animate-bounce">🔍</div>
                <div>
                  <h2 className="text-3xl font-bold mb-3">No Services Yet</h2>
                  <p className="text-gray-400 text-lg mb-8">
                    Connect your Proxmox instance to discover and monitor your services
                  </p>
                  <ProxmoxConnector />
                </div>
              </div>
            </div>
          ) : (
            <ServiceGrid services={services} />
          )}
        </main>

        {/* Footer */}
        <footer className="border-t border-gray-800/50 backdrop-blur-xl bg-gray-900/30 mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-gray-400 text-sm">
              <p>🎯 Smart Service Dashboard for Proxmox VE</p>
              <p>Made with ❤️ • {new Date().getFullYear()}</p>
            </div>
          </div>
        </footer>
      </div>

      <style>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-3000 {
          animation-delay: 3s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
}

export default App;
