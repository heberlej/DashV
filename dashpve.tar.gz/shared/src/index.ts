// Shared types for DashPVE

export interface Service {
  id: string;
  name: string;
  url: string;
  icon?: string;
  description?: string;
  containerName: string;
  containerType: 'lxc' | 'qemu';
  containerId: number;
  port: number;
  ip: string;
  lastUpdated: Date;
}

export interface ProxmoxConfig {
  host: string;
  user: string;
  token: string;
}
